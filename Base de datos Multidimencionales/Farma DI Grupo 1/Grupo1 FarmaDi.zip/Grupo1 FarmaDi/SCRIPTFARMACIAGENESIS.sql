-- =============================================
-- BASE DE DATOS: PHARMACYSYSTEM0DB
-- =============================================
USE [master]
GO

CREATE DATABASE [PHARMACYSYSTEM0DB]


USE [PHARMACYSYSTEM0DB]
GO

-- =============================================
-- SECUENCIAS
-- =============================================
CREATE SEQUENCE [dbo].[PurchaseNumSequence] 
 AS [int]
 START WITH 101011
 INCREMENT BY 1
 MINVALUE -2147483648
 MAXVALUE 2147483647
 CACHE
GO

-- =============================================
-- TABLAS INDEPENDIENTES (SIN FOREIGN KEYS)
-- =============================================

-- Tabla de Roles
CREATE TABLE [dbo].[Roles](
    [RolId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [RolName] [nvarchar](100) NULL,
    [CreationDate] [datetime] NULL DEFAULT (getdate()),
    [IsActive] [bit] NULL
)
GO

-- Tabla de Categor�as
CREATE TABLE [dbo].[Categories](
    [CategoryId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [CategoryName] [nvarchar](100) NOT NULL,
    [CategoryDescription] [nvarchar](200) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de Marcas
CREATE TABLE [dbo].[Brands](
    [BrandId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [BrandName] [nvarchar](100) NOT NULL,
    [BrandDescription] [nvarchar](500) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de Presentaciones
CREATE TABLE [dbo].[Presentations](
    [PresentationId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [PresentationDescription] [nvarchar](100) NULL,
    [UnitMeasure] [nvarchar](50) NULL,
    [quantity] [nvarchar](50) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de Concentraciones
CREATE TABLE [dbo].[Concentration](
    [ConcentrationId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [Volume] [nvarchar](50) NULL,
    [Porcentage] [nvarchar](50) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de M�todos de Pago
CREATE TABLE [dbo].[PaymentMethod](
    [PaymentMethodId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [MethodDescription] [nvarchar](50) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de Proveedores
CREATE TABLE [dbo].[Suppliers](
    [SupplierId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [SupplierName] [nvarchar](100) NOT NULL,
    [RNC] [nvarchar](50) NULL,
    [Mail] [nvarchar](100) NULL,
    [SupplierPhone] [nvarchar](20) NULL,
    [SupplierAddress] [nvarchar](100) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de Usuarios
CREATE TABLE [dbo].[Users](
    [UserId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [UserName] [nvarchar](100) NULL,
    [UserLastName] [nvarchar](100) NULL,
    [UserPassword] [nvarchar](max) NULL,
    [Mail] [nvarchar](100) NULL,
    [UserPhone] [nvarchar](30) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1)),
    [RecoveryToken] [datetime] NULL,
    [RecoveryTokenExpiry] [nvarchar](max) NULL,
    [RolId] [int] NULL FOREIGN KEY REFERENCES [Roles]([RolId])
)
GO

-- Tabla de Permisos de Usuario
CREATE TABLE [dbo].[UserPermissions](
    [PermissionId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [RolId] [int] NULL FOREIGN KEY REFERENCES [Roles]([RolId]),
    [ScreenName] [nvarchar](85) NULL,
    [CreationDate] [datetime] NULL DEFAULT (getdate())
)
GO

-- Tabla de Relaci�n Usuario-Rol
CREATE TABLE [dbo].[UserRoles](
    [UserId] [int] NOT NULL,
    [RolId] [int] NOT NULL,
    PRIMARY KEY CLUSTERED ([UserId] ASC, [RolId] ASC),
    FOREIGN KEY ([UserId]) REFERENCES [Users]([UserId]),
    FOREIGN KEY ([RolId]) REFERENCES [Roles]([RolId])
)
GO

-- Tabla de Maestro de Retornos
CREATE TABLE [dbo].[MasterReturn](
    [MasterReturnId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [Reason] [nvarchar](200) NULL,
    [ReturnPolicy] [nvarchar](200) NULL,
    [Quantity] [int] NULL,
    [Price] [decimal](10, 2) NULL,
    [Total] [decimal](10, 2) NULL
)
GO

-- =============================================
-- TABLAS DEPENDIENTES (CON FOREIGN KEYS)
-- =============================================

-- Tabla de Productos
CREATE TABLE [dbo].[Products](
    [ProductId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ProductTradeName] [nvarchar](100) NOT NULL,
    [ProductGenericName] [nvarchar](100) NULL,
    [CategoryId] [int] NULL FOREIGN KEY REFERENCES [Categories]([CategoryId]),
    [PresentationId] [int] NULL FOREIGN KEY REFERENCES [Presentations]([PresentationId]),
    [ConcentrationId] [int] NULL FOREIGN KEY REFERENCES [Concentration]([ConcentrationId]),
    [SupplierId] [int] NULL FOREIGN KEY REFERENCES [Suppliers]([SupplierId]),
    [BrandId] [int] NULL FOREIGN KEY REFERENCES [Brands]([BrandId]),
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de Precios de Productos
CREATE TABLE [dbo].[ProductPricing](
    [Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ProductId] [int] NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [SalesPrice] [decimal](18, 2) NULL,
    [PurchasePrice] [decimal](18, 2) NULL,
    [CriticalStock] [int] NULL
)
GO

-- Tabla de Lotes de Productos
CREATE TABLE [dbo].[ProductBatches](
    [BatchId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [BatchNumber] [nvarchar](50) NULL,
    [ManufacturingDate] [datetime] NULL,
    [ExpirationDate] [datetime] NULL,
    [Quantity] [int] NULL,
    [ProductId] [int] NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de Stock
CREATE TABLE [dbo].[Stock](
    [StockId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [BatchId] [int] NULL FOREIGN KEY REFERENCES [ProductBatches]([BatchId]),
    [AvailableQuantity] [int] NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [ProductId] [int] NOT NULL DEFAULT ((0))
)
GO

-- Tabla de Relaci�n Proveedor-Marca
CREATE TABLE [dbo].[SupplierBrand](
    [BrandId] [int] NOT NULL,
    [SupplierId] [int] NOT NULL,
    [ISMainSupplier] [bit] NULL DEFAULT ((0)),
    PRIMARY KEY CLUSTERED ([BrandId] ASC, [SupplierId] ASC),
    FOREIGN KEY ([BrandId]) REFERENCES [Brands]([BrandId]),
    FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers]([SupplierId])
)
GO

-- Tabla de Ventas
CREATE TABLE [dbo].[sale](
    [SaleId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [UserId] [int] NULL FOREIGN KEY REFERENCES [Users]([UserId]),
    [Total] [decimal](18, 2) NULL,
    [RegisteredDate] [datetime] NULL
)
GO

-- Tabla de Facturas
CREATE TABLE [dbo].[Invoices](
    [InvoiceId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ClientName] [nvarchar](100) NULL,
    [UserId] [int] NULL FOREIGN KEY REFERENCES [Users]([UserId]),
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [SubTotal] [decimal](10, 2) NULL,
    [Isprinted] [bit] NULL DEFAULT ((0)),
    [Discount] [decimal](10, 2) NULL,
    [Total] [decimal](10, 2) NULL
)
GO

-- Tabla de Detalles de Ventas
CREATE TABLE [dbo].[SalesDetails](
    [SalesDetailId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [Quantity] [int] NULL,
    [ProductId] [int] NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [UnitPrice] [decimal](10, 2) NULL,
    [TotalPrice] [decimal](10, 2) NULL,
    [PaymentMethodId] [int] NULL FOREIGN KEY REFERENCES [PaymentMethod]([PaymentMethodId]),
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [SaleId] [int] NULL FOREIGN KEY REFERENCES [sale]([SaleId])
)
GO

-- Tabla de Detalles de Facturas
CREATE TABLE [dbo].[InvoicesDetails](
    [InvoicesDetailId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [Quantity] [int] NULL,
    [ProductId] [int] NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [TotalPrice] [decimal](10, 2) NULL,
    [InvoiceId] [int] NULL FOREIGN KEY REFERENCES [Invoices]([InvoiceId]),
    [RegisteredDate] [datetime] NULL DEFAULT (getdate())
)
GO

-- Tabla de Compras
CREATE TABLE [dbo].[Purchases](
    [PurchaseId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [SupplierId] [int] NULL FOREIGN KEY REFERENCES [Suppliers]([SupplierId]),
    [UserId] [int] NULL FOREIGN KEY REFERENCES [Users]([UserId]),
    [Total] [decimal](10, 2) NULL,
    [Observations] [nvarchar](200) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [PurchaseNum] [int] NULL
)
GO

-- Tabla de Detalles de Compra
CREATE TABLE [dbo].[PurchasingDetail](
    [PurchaseDetailId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [PurchaseId] [int] NULL FOREIGN KEY REFERENCES [Purchases]([PurchaseId]),
    [ProductId] [int] NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [BatchId] [int] NULL FOREIGN KEY REFERENCES [ProductBatches]([BatchId]),
    [Quantity] [int] NULL,
    [UnitPrice] [decimal](10, 2) NULL,
    [TotalPrice] [decimal](10, 2) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate())
)
GO

-- Tabla de Movimientos de Inventario
CREATE TABLE [dbo].[Movements](
    [MovementId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ProductId] [int] NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [MovementType] [nvarchar](50) NULL,
    [Quantity] [int] NULL,
    [UserId] [int] NULL FOREIGN KEY REFERENCES [Users]([UserId]),
    [BatchId] [int] NULL FOREIGN KEY REFERENCES [ProductBatches]([BatchId]),
    [Remarks] [nvarchar](200) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate())
)
GO

-- Tabla de Cabecera de Movimientos
CREATE TABLE [dbo].[MovementHeader](
    [MovementHeaderId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [MovementType] [nvarchar](50) NULL,
    [UserId] [int] NOT NULL FOREIGN KEY REFERENCES [Users]([UserId]),
    [Remarks] [nvarchar](200) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate()),
    [Isactive] [bit] NULL DEFAULT ((1))
)
GO

-- Tabla de Detalle de Movimientos
CREATE TABLE [dbo].[MovementDetail](
    [MovementDetailId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [MovementHeaderId] [int] NOT NULL FOREIGN KEY REFERENCES [MovementHeader]([MovementHeaderId]),
    [ProductId] [int] NOT NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [BatchId] [int] NOT NULL FOREIGN KEY REFERENCES [ProductBatches]([BatchId]),
    [Quantity] [int] NOT NULL
)
GO

-- Tabla de Bajas de Inventario
CREATE TABLE [dbo].[InventoryLoss](
    [LowId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [BatchId] [int] NULL FOREIGN KEY REFERENCES [ProductBatches]([BatchId]),
    [Quantity] [int] NULL,
    [ProductId] [int] NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [UserId] [int] NULL FOREIGN KEY REFERENCES [Users]([UserId]),
    [Reason] [nvarchar](500) NULL,
    [RegisteredDate] [datetime] NULL DEFAULT (getdate())
)
GO

-- Tabla de Retornos de Productos
CREATE TABLE [dbo].[ProductReturns](
    [ReturnId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ReturnType] [nvarchar](50) NULL,
    [ReturnDescription] [nvarchar](200) NULL,
    [InvoiceId] [int] NULL FOREIGN KEY REFERENCES [Invoices]([InvoiceId]),
    [ProductId] [int] NULL FOREIGN KEY REFERENCES [Products]([ProductId]),
    [MasterReturnId] [int] NULL FOREIGN KEY REFERENCES [MasterReturn]([MasterReturnId]),
    [RegisteredDate] [datetime] NULL DEFAULT (getdate())
)
GO

-- =============================================
-- TIPOS DE TABLA DEFINIDOS POR EL USUARIO
-- =============================================

CREATE TYPE [dbo].[PurchaseDetails] AS TABLE(
    [ProductId] [int] NULL,
    [BatchId] [int] NULL,
    [UnitPrice] [decimal](18, 2) NULL,
    [TotalPrice] [decimal](18, 2) NULL
)
GO

CREATE TYPE [dbo].[PurchaseDetailsType] AS TABLE(
    [ProductId] [int] NOT NULL,
    [Quantity] [int] NOT NULL,
    [UnitPrice] [decimal](18, 2) NOT NULL,
    [BatchNumber] [nvarchar](50) NOT NULL,
    [ManufacturingDate] [date] NULL,
    [ExpirationDate] [date] NOT NULL
)
GO

CREATE TYPE [dbo].[PurchaseDetailType] AS TABLE(
    [RowId] [int] NOT NULL PRIMARY KEY,
    [ProductId] [int] NULL,
    [BatchNumber] [nvarchar](100) NULL,
    [ManufacturingDate] [date] NULL,
    [ExpirationDate] [date] NULL,
    [Quantity] [int] NULL,
    [UnitPrice] [decimal](10, 2) NULL
)
GO

CREATE TYPE [dbo].[SalesDetalilsType] AS TABLE(
    [Quantity] [int] NOT NULL,
    [ProductId] [int] NOT NULL
)
GO
